<?php
td_demo_media::add_image_to_media_gallery('td_pic_1', 'https://cloud.tagdiv.com/demos/Newspaper/amberlight_pro/media/55.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_2', 'https://cloud.tagdiv.com/demos/Newspaper/amberlight_pro/media/54.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_3', 'https://cloud.tagdiv.com/demos/Newspaper/amberlight_pro/media/53.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_4', 'https://cloud.tagdiv.com/demos/Newspaper/amberlight_pro/media/52.jpg');

