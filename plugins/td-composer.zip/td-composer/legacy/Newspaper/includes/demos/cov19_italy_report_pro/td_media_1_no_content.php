<?php
td_demo_media::add_image_to_media_gallery('tdx_pic_1', 'https://cloud.tagdiv.com/demos/Newspaper/cov19_italy_report_pro/img/13.jpg');
td_demo_media::add_image_to_media_gallery('tdx_pic_2', 'https://cloud.tagdiv.com/demos/Newspaper/cov19_italy_report_pro/img/corhaz-300.jpg');
td_demo_media::add_image_to_media_gallery('tdx_pic_3', 'https://cloud.tagdiv.com/demos/Newspaper/cov19_italy_report_pro/img/aaa3.png');
td_demo_media::add_image_to_media_gallery('tdx_pic_4', 'https://cloud.tagdiv.com/demos/Newspaper/cov19_italy_report_pro/img/aaa5.png');
td_demo_media::add_image_to_media_gallery('tdx_pic_5', 'https://cloud.tagdiv.com/demos/Newspaper/cov19_italy_report_pro/img/caca5.jpg');
td_demo_media::add_image_to_media_gallery('tdx_pic_6', 'https://cloud.tagdiv.com/demos/Newspaper/cov19_italy_report_pro/img/xxx_bg_xxx.png');
td_demo_media::add_image_to_media_gallery('tdx_pic_7', 'https://cloud.tagdiv.com/demos/Newspaper/cov19_italy_report_pro/img/17.jpg');