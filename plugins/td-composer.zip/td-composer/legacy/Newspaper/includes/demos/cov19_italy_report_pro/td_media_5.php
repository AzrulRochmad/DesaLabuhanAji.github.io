<?php
td_demo_media::add_image_to_media_gallery('tdx_pic_7', 'https://cloud.tagdiv.com/demos/Newspaper/cov19_italy_report_pro/img/17.jpg');

