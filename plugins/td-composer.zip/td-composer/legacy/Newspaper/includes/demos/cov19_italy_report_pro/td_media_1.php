<?php
td_demo_media::add_image_to_media_gallery('td_pic_1', 'https://cloud.tagdiv.com/demos/Newspaper/cov19_italy_report_pro/img/53.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_2', 'https://cloud.tagdiv.com/demos/Newspaper/cov19_italy_report_pro/img/52.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_3', 'https://cloud.tagdiv.com/demos/Newspaper/cov19_italy_report_pro/img/51.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_4', 'https://cloud.tagdiv.com/demos/Newspaper/cov19_italy_report_pro/img/50.jpg');

