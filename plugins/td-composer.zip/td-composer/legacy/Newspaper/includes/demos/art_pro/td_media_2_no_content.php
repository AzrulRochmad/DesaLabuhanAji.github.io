<?php
/**
 * Created by ra on 5/14/2015.
 */

//mobile & login bg
td_demo_media::add_image_to_media_gallery('td_login_bg',                  "http://demo_content.tagdiv.com/Newspaper_6/art_pro/login-bg.jpg");
td_demo_media::add_image_to_media_gallery('td_mobile_bg',                  "http://demo_content.tagdiv.com/Newspaper_6/art_pro/mobile-bg.jpg");

//img search
td_demo_media::add_image_to_media_gallery('td_pic_9',                   "http://demo_content.tagdiv.com/Newspaper_6/art_pro/9.jpg");