<?php

// post photos
td_demo_media::add_image_to_media_gallery('td_pic_p3',                  "http://demo_content.tagdiv.com/Newspaper_6/blog_beauty/p3.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_p4',                  "http://demo_content.tagdiv.com/Newspaper_6/blog_beauty/p4.jpg");

