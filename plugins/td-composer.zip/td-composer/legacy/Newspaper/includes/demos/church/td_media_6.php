<?php
/**
 * Created by ra on 6/13/2015.
 */


td_demo_media::add_image_to_media_gallery('td_logo_footer',             'http://demo_content.tagdiv.com/Newspaper_6/church/logo-footer.png');
td_demo_media::add_image_to_media_gallery('td_logo_footer_retina',      'http://demo_content.tagdiv.com/Newspaper_6/church/logo-footer@2x.png');

//banner
td_demo_media::add_image_to_media_gallery('td_church_homepage_banner',  'http://demo_content.tagdiv.com/Newspaper_6/church/banner.jpg');

//ads
td_demo_media::add_image_to_media_gallery('td_church_homepage_ad',      "http://demo_content.tagdiv.com/Newspaper_6/church/rec-big.jpg");
