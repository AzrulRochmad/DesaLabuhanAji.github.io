<?php
td_demo_media::add_image_to_media_gallery('tdx_pic_7', 'https://cloud.tagdiv.com/demos/Newspaper/beauty_pro/media/date-img.jpg');
td_demo_media::add_image_to_media_gallery('tdx_pic_8', 'https://cloud.tagdiv.com/demos/Newspaper/beauty_pro/media/reclama2.jpg');
td_demo_media::add_image_to_media_gallery('tdx_pic_9', 'https://cloud.tagdiv.com/demos/Newspaper/beauty_pro/media/reclama3.jpg');
td_demo_media::add_image_to_media_gallery('tdx_pic_10', 'https://cloud.tagdiv.com/demos/Newspaper/beauty_pro/media/mobile-bg.jpg');

